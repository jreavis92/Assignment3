using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ReavisJeffreyAssignment3.Data;
using ReavisJeffreyAssignment3.Data.Entities; // Ensure this is correctly pointing to your entity class
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ReavisJeffreyAssignment3.Pages
{
    public class ClassesModel : PageModel
    {
        private readonly MyApplicationDbContext _context;

        // Adjust the constructor parameter to match the field name
        public ClassesModel(MyApplicationDbContext context)
        {
            _context = context;
        }

        // Ensure the type for Classes matches your entity
        public List<Classes> Classes { get; set; } // Adjust 'Class' if your entity has a different name

        public async Task<IActionResult> OnGetAsync()
        {
            // Use the correct field name here
            Classes = await _context.Classes.ToListAsync(); // Adjust 'Classes' if your DbSet has a different name

            return Page();
        }
    }
}
