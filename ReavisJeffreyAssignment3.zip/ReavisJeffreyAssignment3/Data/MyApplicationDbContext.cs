﻿using Microsoft.EntityFrameworkCore;
using ReavisJeffreyAssignment3.Data.Entities;
using Microsoft.Identity.Client;

namespace ReavisJeffreyAssignment3.Data
{
    public class MyApplicationDbContext : DbContext
    {
        public MyApplicationDbContext(DbContextOptions<MyApplicationDbContext> options) : base(options) 
        { 
        }

        public DbSet<Classes> Classes { get; set; }
    }
}
