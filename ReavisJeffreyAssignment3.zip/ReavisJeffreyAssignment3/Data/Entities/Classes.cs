﻿using System.ComponentModel.DataAnnotations;

namespace ReavisJeffreyAssignment3.Data.Entities
{
    public class Classes
    {
        [Key]
        public int ClassId { get; set; }
        public string ClassName { get; set; }
        public string CourseID { get; set; }

    }
}
